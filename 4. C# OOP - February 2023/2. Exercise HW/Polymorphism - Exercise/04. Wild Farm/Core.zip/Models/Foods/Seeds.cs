﻿namespace WildFarm.Models.Foods;

public class Seeds : Food
{
    public Seeds(int quantity)
        : base(quantity)
    {
    }
}
