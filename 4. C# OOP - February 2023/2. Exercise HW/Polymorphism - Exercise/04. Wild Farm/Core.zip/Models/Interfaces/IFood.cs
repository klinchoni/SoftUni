﻿namespace WildFarm.Models.Interfaces;

public interface IFood
{
    public int Quantity { get; }
}
